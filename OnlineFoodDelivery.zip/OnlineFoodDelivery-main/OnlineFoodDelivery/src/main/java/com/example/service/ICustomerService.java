package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entities.Customer;

@Service
public interface ICustomerService {

	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer removeCustomer(Customer customer);
	public Customer viewCustomer(int id );
	public List<Customer> viewAllCustomer(); 
	
}
