package com.example.entities;

import java.time.LocalDateTime;

public class Bill {
private int billId;
private OrderDetails order;
private int totalItem;
private double totalCost;
LocalDateTime billDate;
}
