package com.example.entities;

public class Category {

	private String catId;
	private String categoryName;
}
