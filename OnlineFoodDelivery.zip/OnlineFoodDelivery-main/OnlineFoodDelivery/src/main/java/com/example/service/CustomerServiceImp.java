package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Customer;
import com.example.repository.CustomerJPARepository;

@Service
public class CustomerServiceImp implements ICustomerService {

	@Autowired
	private CustomerJPARepository customerRepository;

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.saveAndFlush(customer);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.saveAndFlush(customer);
		return customer;
	}

	@Override
	public Customer removeCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.delete(customer);
		
		return customer;
	}

	@Override
	public Customer viewCustomer(int id) {
		// TODO Auto-generated method stub
		Optional<Customer>prod=customerRepository.findById(id);
		return prod.get();
	}

	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	

}
