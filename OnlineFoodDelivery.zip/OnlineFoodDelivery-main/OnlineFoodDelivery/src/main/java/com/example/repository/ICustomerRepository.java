package com.example.repository;
/*
import java.util.List;

import com.example.entities.Customer;



public interface ICustomerRepository {

	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer removeCustomer(Customer customer);
	public Customer viewCustomer(int id );
	public List<Customer> viewAllCustomer(String restaurantname); 
}
*/
