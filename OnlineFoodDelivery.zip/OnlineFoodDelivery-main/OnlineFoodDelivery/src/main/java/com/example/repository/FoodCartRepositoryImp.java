/*package com.example.repository;
import java.util.*;
import javax.persistence.*;
import org.springframework.stereotype.*;
import com.example.entities.FoodCart;
import com.example.entities.Item;
@Repository
public class FoodCartRepositoryImp implements ICartRepository{
	@PersistenceContext
	private EntityManager em;
	@Override
	public FoodCart addItemToCart(FoodCart cart,Item item) {
		em.persist(item);
		return cart;
	}
	@Override
	public FoodCart increaseQuantity(FoodCart cart,Item item,int quantity) {
		
	}
	@Override
	public FoodCart reduceQuantity(FoodCart cart,Item item,int quantity) {
		
	}
	@Override
	public FoodCart removeItem(FoodCart cart,Item item) {
		
	}
	@Override
	public FoodCart clearCart(FoodCart cart) {
		
	}
}*/