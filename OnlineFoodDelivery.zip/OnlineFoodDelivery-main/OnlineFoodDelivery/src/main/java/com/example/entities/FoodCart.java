package com.example.entities;

import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="FoodCart")
public class FoodCart {
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="fcart_seq")
	@SequenceGenerator(name="fcart_seq",sequenceName="fcart_seq",allocationSize=1)
	//@GeneratedValue
	@Column(name="cartId")
	private String cartId;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer",referencedColumnName="customerId")
	private Customer customer;
	private List<Item> itemList;
		public FoodCart(String cartId, Customer customer, List<Item> itemList) {
			this.cartId=cartId;
			this.customer=customer;
			this.itemList=itemList;
		}
	public void setCartId(String cartId) {
		this.cartId=cartId;
	}
	public void setCustomer(Customer customer) {
		this.customer=customer;
	}
	public void setItemList(List<Item> itemList) {
		this.itemList=itemList;
	}
	public String getCartId() {
		return cartId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public List<Item> getItemList(){
		return itemList;
	}
	@Override
	public String toString() {
		return "Cart Id:"+cartId+" Customer:"+customer+" ItemList:"+itemList;
	}
}