package com.cg.OnilneFoodDelivery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.OnilneFoodDelivery.entities.Category;
import com.cg.OnilneFoodDelivery.repository.ICategoryJPARepository;
@Service
public class CategoryServiceImpl implements ICategoryService {
	
	@Autowired
	private ICategoryJPARepository categoryRepository;

	@Override
	public Category addCategory(Category cat) {
		// TODO Auto-generated method stub
		Category c =categoryRepository.save(cat);
		return c;
	}

	@Override
	public Category updateCategory(Category cat) {
		// TODO Auto-generated method stub
		Category c =categoryRepository.saveAndFlush(cat);
		return c;
	}

	@Override
	public void removeCategory(int catId) {
		// TODO Auto-generated method stub
		categoryRepository.deleteById(catId);
	}

	@Override
	public Category viewCategory(int id) {
		// TODO Auto-generated method stub
		Optional<Category> cat =categoryRepository.findById(id);
		return cat.get();
	}

	@Override
	public List<Category> viewAllCategory() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

}
