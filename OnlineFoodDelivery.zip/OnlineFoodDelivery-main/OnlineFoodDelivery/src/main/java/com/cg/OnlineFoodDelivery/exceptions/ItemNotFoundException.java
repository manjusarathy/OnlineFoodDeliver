package com.cg.OnlineFoodDelivery.exceptions;

public class ItemNotFoundException extends Exception {
	private static final long serialVersionUID = -9090587718141879101L;
	
	public ItemNotFoundException() {
	}
	
	public ItemNotFoundException(String message) {
		super(message);
	}

}