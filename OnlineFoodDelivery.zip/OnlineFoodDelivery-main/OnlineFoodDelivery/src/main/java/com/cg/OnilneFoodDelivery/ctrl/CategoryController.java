package com.cg.OnilneFoodDelivery.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.OnilneFoodDelivery.entities.Category;
import com.cg.OnilneFoodDelivery.entities.Customer;
import com.cg.OnilneFoodDelivery.payload.BaseRespose;
import com.cg.OnilneFoodDelivery.service.ICategoryService;

@RestController
@CrossOrigin
@RequestMapping("/Category")
public class CategoryController {

	@Autowired
	private ICategoryService categoryService;
	@GetMapping("/{catId}")
	public ResponseEntity<Category> findCustomerbyId(@PathVariable("catId")int catId){
		Category cats= categoryService.viewCategory(catId);
		if(cats==null) {
			return new ResponseEntity("Sorry! Category not found!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Category>(cats,HttpStatus.OK);
	}
	@GetMapping("/allCategory")
	public ResponseEntity<List<Category>> getAllCategory(){
		List<Category> category= categoryService.viewAllCategory();
		if(category.isEmpty()) {
			return new ResponseEntity("Sorry! Category not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Category>>(category, HttpStatus.OK);
	}
	@PostMapping("/addCategory")
	public ResponseEntity<Category> insertCategory(@RequestBody Category cat){
		Category category= categoryService.addCategory(cat);
		if(category==null){
			return new ResponseEntity("Sorry! Category not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Category>(category, HttpStatus.OK);
	}
	@DeleteMapping("/deleteCategory/{catId}")
	public ResponseEntity<?> deleteCategory(@PathVariable("catId")int catId){
		 categoryService.removeCategory(catId);
		return new ResponseEntity<>("Category Deleted", HttpStatus.OK);
	}
	@PutMapping("/updateCategory")
	public ResponseEntity<?> updateCategory(@RequestBody Category categorys){
		categoryService.updateCategory(categorys);
		BaseRespose baseResponse= new BaseRespose();
		baseResponse.setStatusCode(1);
		baseResponse.setResponse(categorys);
		
		return new ResponseEntity<>(baseResponse, HttpStatus.OK);
	}
}
