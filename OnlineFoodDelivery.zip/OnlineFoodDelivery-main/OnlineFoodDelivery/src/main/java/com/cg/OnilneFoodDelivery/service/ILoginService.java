package com.cg.OnilneFoodDelivery.service;

import com.cg.OnilneFoodDelivery.entities.Login;

public interface ILoginService {
	
	public Login signIn(Login login);
	public Login signOut(Login login);
}
