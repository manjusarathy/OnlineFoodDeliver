package com.cg.OnilneFoodDelivery.entities;

import java.time.LocalDateTime;
import java.util.List;

public class OrderDetails {

	private int orderId;
	private LocalDateTime orderDate;
	private FoodCart cart;
	private String orderStatus;
	

}
