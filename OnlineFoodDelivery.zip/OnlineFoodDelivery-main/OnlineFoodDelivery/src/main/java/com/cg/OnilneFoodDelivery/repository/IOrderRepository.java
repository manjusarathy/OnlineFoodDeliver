package com.cg.OnilneFoodDelivery.repository;

import java.util.List;

import com.cg.OnilneFoodDelivery.entities.Customer;
import com.cg.OnilneFoodDelivery.entities.OrderDetails;
import com.cg.OnilneFoodDelivery.entities.Restaurant;

public interface IOrderRepository {

	public OrderDetails addOrder(OrderDetails order);
	public OrderDetails updateOrder(OrderDetails order);
	public OrderDetails removeOrder(OrderDetails order);
	public OrderDetails viewOrder(OrderDetails order);
	public List<OrderDetails> viewAllOrders(Restaurant resName);
	public List<OrderDetails> viewAllOrders(Customer customer);
	
}
