package com.cg.OnilneFoodDelivery.payload;

public class BaseRespose {
	private Object response;
	private int statusCode;
	
	public Object getResponse() {
		return response;
	}
	public void setResponse(Object response) {
		this.response = response;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
}
