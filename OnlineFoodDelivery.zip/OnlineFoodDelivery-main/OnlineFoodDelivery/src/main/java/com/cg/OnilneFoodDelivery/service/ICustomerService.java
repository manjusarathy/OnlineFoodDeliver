package com.cg.OnilneFoodDelivery.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.OnilneFoodDelivery.entities.Customer;

@Service
public interface ICustomerService {

	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public void removeCustomer(int customerId);
	public Customer viewCustomer(int id );
	public List<Customer> viewAllCustomer(); 
	
}
