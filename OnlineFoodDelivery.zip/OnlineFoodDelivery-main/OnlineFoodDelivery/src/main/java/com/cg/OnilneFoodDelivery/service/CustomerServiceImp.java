package com.cg.OnilneFoodDelivery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.OnilneFoodDelivery.entities.Customer;
import com.cg.OnilneFoodDelivery.repository.CustomerJPARepository;

@Service
public class CustomerServiceImp implements ICustomerService {

	@Autowired
	private CustomerJPARepository customerRepository;

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer cust=customerRepository.save(customer);
		return cust;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.saveAndFlush(customer);
		return customer;
	}

	@Override
	public void removeCustomer(int customerId) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(customerId);
		
		
	}

	@Override
	public Customer viewCustomer(int id) {
		// TODO Auto-generated method stub
		Optional<Customer>prod=customerRepository.findById(id);
		return prod.get();
	}

	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	

}
