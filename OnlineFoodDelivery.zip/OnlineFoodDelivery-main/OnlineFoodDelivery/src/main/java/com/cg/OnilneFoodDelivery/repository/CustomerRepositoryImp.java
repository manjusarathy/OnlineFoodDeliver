package com.cg.OnilneFoodDelivery.repository;
/*package com.example.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.example.entities.Customer;

@Repository
public class CustomerRepositoryImp implements ICustomerRepository {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		em.persist(customer);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		em.merge(customer);
		return customer;
	}

	@Override
	public Customer removeCustomer(Customer customer) {
		// TODO Auto-generated method stub
		em.remove(customer);
		return customer;
	}

	@Override
	public Customer viewCustomer(int id) {
		// TODO Auto-generated method stub
		
		return em.find(Customer.class, id);
	}

	@Override
	public List<Customer> viewAllCustomer(String restaurantname) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> custqury=em.createQuery("select c from Customer c",Customer.class);
		return custqury.getResultList();
		
	}

}*/
