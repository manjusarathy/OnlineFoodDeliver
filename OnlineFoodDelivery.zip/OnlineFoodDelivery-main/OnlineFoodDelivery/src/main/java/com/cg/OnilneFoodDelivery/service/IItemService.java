package com.cg.OnilneFoodDelivery.service;

import java.util.List;

import com.cg.OnilneFoodDelivery.entities.Category;
import com.cg.OnilneFoodDelivery.entities.Item;
import com.cg.OnilneFoodDelivery.entities.Restaurant;

public interface IItemService {

	public Item addItem(Item item);
	public Item viewItem(int id);
	public Item updateItem(Item item);
	public void removeItem(int itemId);
	public List<Item> viewAllItems(Restaurant res);
	public List<Item> viewAllItems(int catId);
	public List<Item> viewAllItemsByName(String name);
	
}
