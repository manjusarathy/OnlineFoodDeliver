package com.cg.OnilneFoodDelivery.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.OnilneFoodDelivery.entities.Customer;
import com.cg.OnilneFoodDelivery.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private ICustomerService customerService;
	
	@GetMapping("/cust/{customerId}")
	public ResponseEntity<Customer> findCustomerbyId(@PathVariable("customerId")int customerId){
		Customer customer= customerService.viewCustomer(customerId);
		if(customer==null) {
			return new ResponseEntity("Sorry! Customer not found!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}
	@GetMapping("/allCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		List<Customer> customer= customerService.viewAllCustomer();
		if(customer.isEmpty()) {
			return new ResponseEntity("Sorry! Customer not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customer, HttpStatus.OK);
	}
	@Transactional
	@PostMapping("/addCustomers")
	public ResponseEntity<Customer> insertCustomer(@RequestBody Customer customer){
		Customer customers= customerService.addCustomer(customer);
		if(customers==null){
			return new ResponseEntity("Sorry! Customer not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(customers, HttpStatus.OK);
	}
	@Transactional
	@DeleteMapping("/deleteCustomers/{customerId}")
	public ResponseEntity<?> deleteCustomer(@PathVariable("customerId")int customerId){
		customerService.removeCustomer(customerId);
		
		return new ResponseEntity<>("CustomerI delete", HttpStatus.OK);
	}
	@Transactional
	@PutMapping("/updateCustomers")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer){
		Customer customers= customerService.updateCustomer(customer);
		if(customers==null)
		{
			return new ResponseEntity("Sorry! Customer not available!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(customers, HttpStatus.OK);
	}
}
