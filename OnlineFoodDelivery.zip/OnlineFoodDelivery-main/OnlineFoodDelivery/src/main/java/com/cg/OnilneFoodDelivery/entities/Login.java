package com.cg.OnilneFoodDelivery.entities;

public class Login {

	private String userid;
	private String userName;
	private String password;
	
}
