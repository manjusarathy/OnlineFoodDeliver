package com.cg.OnilneFoodDelivery.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.OnilneFoodDelivery.entities.Category;
import com.cg.OnilneFoodDelivery.entities.Item;
import com.cg.OnilneFoodDelivery.entities.Restaurant;

public interface IItemJPARepository extends JpaRepository<Item,Integer>{

	//Item deleteById(Optional<Item> item);

	/*public Item addItem(Item item);
	public Item viewItem(String id);
	public Item updateItem(Item item);
	public Item removeItem(String id);
	public List<Item> viewAllItems(Restaurant res);
	public List<Item> viewAllItems(Category cat);
	public List<Item> viewAllItemsByName(String name);*/
	
	
}
