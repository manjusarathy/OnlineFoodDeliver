package com.cg.OnilneFoodDelivery.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.cg.OnilneFoodDelivery.entities.Category;
//@Service
public interface ICategoryService {

	public Category addCategory(Category cat);
	public Category updateCategory(Category cat);
	public void removeCategory(int catId);
	public Category viewCategory(int id);
	public List<Category> viewAllCategory();
}
