package com.cg.OnlineFoodDelivery.exceptions;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cg.OnilneFoodDelivery.payload.BaseErrorResponse;
import com.cg.OnilneFoodDelivery.payload.ValidationErrorResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@ControllerAdvice
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	private static Logger logger=LoggerFactory.getLogger(CustomGlobalExceptionHandler.class);
	 @ExceptionHandler(OperationFailedException.class)
		public final ResponseEntity<?> handleOperationFailedViolation(OperationFailedException ex,
				WebRequest request) {
			
			BaseErrorResponse errors = new BaseErrorResponse();
			errors.setTimestamp(LocalDateTime.now());
			errors.setMessage(ex.getMessage());
			errors.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			
			return new ResponseEntity<>(errors, HttpStatus.INTERNAL_SERVER_ERROR);
	 }	

	 private final String BAD_REQUEST = "BAD_REQUEST";
		
		@ExceptionHandler(CustomerNotFoundException.class)
		public ResponseEntity<?> customHandleNotFound(Exception ex, WebRequest request) {
			
			BaseErrorResponse errors = new BaseErrorResponse();
			errors.setTimestamp(LocalDateTime.now());
			errors.setMessage(ex.getMessage());
			errors.setStatusCode(-1);
			logger.error("Exception::"+ex.getMessage());
			return new ResponseEntity<>(errors,HttpStatus.NOT_FOUND);

		}	
		
		@ExceptionHandler(ItemNotFoundException.class)
		public ResponseEntity<?> customHandleNotFound1(Exception ex, WebRequest request) {
			
			BaseErrorResponse errors = new BaseErrorResponse();
			errors.setTimestamp(LocalDateTime.now());
			errors.setMessage(ex.getMessage());
			errors.setStatusCode(-1);
			logger.error("Exception::"+ex.getMessage());
			return new ResponseEntity<>(errors,HttpStatus.NOT_FOUND);

		} 
		
		@ExceptionHandler(ConstraintViolationException.class)
		public final ResponseEntity<ValidationErrorResponse> handleConstraintViolation(ConstraintViolationException ex,
				WebRequest request) {
			List<String> details = ex.getConstraintViolations().parallelStream().map(e -> e.getMessage())
					.collect(Collectors.toList());
			
			ValidationErrorResponse validationErrResp = new ValidationErrorResponse();		
			validationErrResp.setTimestamp(LocalDateTime.now());
			validationErrResp.setMessage(BAD_REQUEST);
			validationErrResp.setStatusCode(HttpStatus.BAD_REQUEST.value());
			validationErrResp.setDetails(details);
			
			return new ResponseEntity<>(validationErrResp, HttpStatus.BAD_REQUEST);
		}


	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<?> customHandleForServerError(Exception ex, WebRequest request) {

		BaseErrorResponse errors = new BaseErrorResponse();
		errors.setTimestamp(LocalDateTime.now());
		errors.setMessage(ex.getMessage());
		errors.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);

	}

}