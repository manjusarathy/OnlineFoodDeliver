package com.cg.OnilneFoodDelivery.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.OnilneFoodDelivery.entities.Customer;
@Repository
public interface CustomerJPARepository extends JpaRepository<Customer,Integer> {

}
