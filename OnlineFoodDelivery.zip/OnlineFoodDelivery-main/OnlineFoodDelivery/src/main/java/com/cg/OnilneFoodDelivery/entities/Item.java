package com.cg.OnilneFoodDelivery.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="item")
public class Item {
	@Id
	@GeneratedValue(generator="item_seq",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="item_seq",sequenceName="item_seq",allocationSize=1)
	@Column(name="item_Id")
	private int itemId;
	@Column(name="item_name")
	private String itemName;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="cat_Id",referencedColumnName = "cat_Id")
	@Transient
	private Category category;
	@Column(name="quantity")
	private int quantity;
	@Column(name="cost")
	private double cost;
	/*@Column(name="restaurantlist")
	private List<Restaurant> restaurants;*/
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	/*public List<Restaurant> getRestaurants() {
		return restaurants;
	}
	public void setRestaurants(List<Restaurant> restaurants) {
		this.restaurants = restaurants;
	}*/
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", category=" + category + ", quantity=" + quantity
				+ ", cost=" + cost + "]";
	}
	public Item(int itemId, String itemName, Category category, int quantity, double cost) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.category = category;
		this.quantity = quantity;
		this.cost = cost;
		//this.restaurants = restaurants;
	}
	public Item() {
		super();
	}
	
	
}
